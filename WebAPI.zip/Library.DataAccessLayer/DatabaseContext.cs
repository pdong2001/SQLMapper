﻿using Library.Common;
using Library.DataModels;
using System;

namespace Library.DataAccessLayer
{
    public class DatabaseContext : DatabaseHelper
    {
        public DatabaseContext(string connectionString) : base(connectionString)
        {
        }
        public EntitySet<Product> Products { get; set; }
    }
}
